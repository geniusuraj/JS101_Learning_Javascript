let name = "Suraj Kumar Sharma\n"
let age = 20
console.log(name, (typeof name));
console.log(age, (typeof age));