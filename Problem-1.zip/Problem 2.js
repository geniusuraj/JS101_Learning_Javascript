let name = "Suraj Kumar Sharma"
console.log(name);
name = "Sanjay Kumar Sharma"
console.log(name);
name = "Suganti Devi"
console.log(name);