let x = "Masai School\n";
y = "A Transformation in Education";
console.log(x, y)